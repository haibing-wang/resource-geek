package com.tuling.compent;

/**
 * Created by smlz on 2019/6/24.
 */
public class Person {

    public Person() {

    }
}
