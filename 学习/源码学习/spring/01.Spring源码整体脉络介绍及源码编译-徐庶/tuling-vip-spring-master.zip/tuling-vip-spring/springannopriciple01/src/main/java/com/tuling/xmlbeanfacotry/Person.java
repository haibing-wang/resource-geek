package com.tuling.xmlbeanfacotry;

/**
 * Created by smlz on 2019/6/5.
 */
public class Person {

    public Person() {
        System.out.println("我是构造函数");
    }
}
