package com.tuling.testconditional.compent;

/**
 * Created by smlz on 2019/5/20.
 */
public class TulingAspect {

    public TulingAspect() {
        System.out.println("我是TulingAspect的构造方法");
    }
}
