package com.tuling.testalias;

/**
 * Created by smlz on 2019/6/4.
 */
public class AliasBean {
}
