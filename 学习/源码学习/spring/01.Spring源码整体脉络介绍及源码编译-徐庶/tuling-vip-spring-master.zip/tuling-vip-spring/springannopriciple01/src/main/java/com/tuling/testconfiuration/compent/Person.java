package com.tuling.testconfiuration.compent;

/**
 * Created by smlz on 2019/5/19.
 */
public class Person {

    public Person() {

    }
}
