package com.tuling.postprocessor;


/**
 * Created by smlz on 2019/6/28.
 */
public class Compent {


    public void init(){
        System.out.println("Compent的初始化方法");
    }

    public Compent() {
        System.out.println("Compent的构造方法");
    }
}
