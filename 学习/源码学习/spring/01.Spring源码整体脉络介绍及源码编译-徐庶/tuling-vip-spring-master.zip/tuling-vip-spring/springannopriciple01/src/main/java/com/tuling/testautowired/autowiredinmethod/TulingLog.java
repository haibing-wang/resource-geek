package com.tuling.testautowired.autowiredinmethod;

import org.springframework.stereotype.Component;

/**
 * Created by smlz on 2019/5/24.
 */
@Component
public class TulingLog {


}
