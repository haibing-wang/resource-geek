package com.tuling.testcompentscan.service;

import org.springframework.stereotype.Service;

/**
 * Created by smlz on 2019/5/19.
 */
@Service
public class TulingService {
}
