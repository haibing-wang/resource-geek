package com.tuling.testcompentscan.dao;

/**
 * Created by smlz on 2019/6/11.
 */
public class BaiduCom {
}
