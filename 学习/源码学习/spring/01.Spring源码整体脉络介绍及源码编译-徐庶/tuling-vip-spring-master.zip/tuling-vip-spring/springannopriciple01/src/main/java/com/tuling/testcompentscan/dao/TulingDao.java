package com.tuling.testcompentscan.dao;

import org.springframework.stereotype.Repository;

/**
 * Created by smlz on 2019/5/19.
 */
@Repository
public class TulingDao {
}
