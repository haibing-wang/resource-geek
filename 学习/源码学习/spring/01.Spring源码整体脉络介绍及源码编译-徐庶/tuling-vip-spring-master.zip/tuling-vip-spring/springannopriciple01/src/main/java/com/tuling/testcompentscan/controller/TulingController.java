package com.tuling.testcompentscan.controller;

import org.springframework.stereotype.Controller;

/**
 * Created by smlz on 2019/5/19.
 */
@Controller
public class TulingController {
}
