package com.tuling.testcompentscan.controller;

/**
 * Created by smlz on 2019/6/11.
 */
public class BaiduCom2 {
}
