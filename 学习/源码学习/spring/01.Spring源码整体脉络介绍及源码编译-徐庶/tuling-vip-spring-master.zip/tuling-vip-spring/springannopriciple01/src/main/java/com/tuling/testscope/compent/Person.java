package com.tuling.testscope.compent;

/**
 * Created by smlz on 2019/5/19.
 */
public class Person {

    public Person() {
        System.out.println("person的构造方法");
    }
}
