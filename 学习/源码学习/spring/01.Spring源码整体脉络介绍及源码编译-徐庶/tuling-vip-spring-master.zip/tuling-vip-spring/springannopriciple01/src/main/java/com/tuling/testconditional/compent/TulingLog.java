package com.tuling.testconditional.compent;

/**
 * Created by smlz on 2019/5/20.
 */
public class TulingLog {

    public TulingLog() {
        System.out.println("我是TulingLog的构造方法");
    }
}
