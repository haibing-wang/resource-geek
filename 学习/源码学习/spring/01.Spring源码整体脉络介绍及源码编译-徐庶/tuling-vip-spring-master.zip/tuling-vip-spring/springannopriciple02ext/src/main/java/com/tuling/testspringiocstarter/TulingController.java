package com.tuling.testspringiocstarter;

import org.springframework.stereotype.Controller;

/**
 * Created by smlz on 2019/6/12.
 */
@Controller
public class TulingController {
}
