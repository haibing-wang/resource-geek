package com.tuling.testspringiocstarter;

/**
 * Created by smlz on 2019/6/13.
 */

public class TulingDataSource {

    public TulingDataSource() {
        System.out.println("TulingDataSource");
    }
}
