package com.tuling.testspringiocstarter;

/**
 * Created by smlz on 2019/6/12.
 */
public class TulingService {

    public TulingService() {
        System.out.println("我是tulingService的构造方法");
    }
}
