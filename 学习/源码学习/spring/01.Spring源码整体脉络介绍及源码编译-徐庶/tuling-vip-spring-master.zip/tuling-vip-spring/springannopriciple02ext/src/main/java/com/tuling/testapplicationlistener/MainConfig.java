package com.tuling.testapplicationlistener;

import org.springframework.context.annotation.ComponentScan;

/**
 * Created by smlz on 2019/5/27.
 */
@ComponentScan(basePackages = {"com.tuling.testapplicationlistener"})
public class MainConfig {
}
