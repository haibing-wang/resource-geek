package com.tuling.testbeanpostpostprocessor;

import org.springframework.stereotype.Component;

/**
 * Created by smlz on 2019/6/2.
 */
@Component
public class CompentB {
}
