package com.tuling.testdependsOn;

/**
 * Created by smlz on 2019/6/13.
 */
public class DependsA {

    public DependsA() {
        System.out.println("DependsA");
    }
}
