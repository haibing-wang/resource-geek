package com.tuling.testbeanpostpostprocessor;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * Created by smlz on 2019/5/31.
 */
@Configuration
@ComponentScan(basePackages = {"com.tuling.testbeanpostpostprocessor"})
public class MainConfig {

}
