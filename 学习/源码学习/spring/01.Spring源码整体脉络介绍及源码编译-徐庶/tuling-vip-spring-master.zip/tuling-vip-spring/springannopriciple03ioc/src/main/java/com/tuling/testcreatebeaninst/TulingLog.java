package com.tuling.testcreatebeaninst;


import org.springframework.stereotype.Component;

/**
 * Created by smlz on 2019/6/3.
 */
public class TulingLog {
}
