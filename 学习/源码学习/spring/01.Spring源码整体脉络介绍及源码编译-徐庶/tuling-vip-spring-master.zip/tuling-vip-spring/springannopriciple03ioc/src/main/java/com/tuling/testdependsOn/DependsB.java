package com.tuling.testdependsOn;

/**
 * Created by smlz on 2019/6/13.
 */
public class DependsB {

    public DependsB() {
        System.out.println("DependsB");
    }
}
