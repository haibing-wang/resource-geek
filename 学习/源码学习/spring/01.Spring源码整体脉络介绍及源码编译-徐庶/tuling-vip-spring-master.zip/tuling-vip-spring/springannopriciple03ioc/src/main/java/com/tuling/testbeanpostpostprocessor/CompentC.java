package com.tuling.testbeanpostpostprocessor;

/**
 * Created by smlz on 2019/6/2.
 */
public class CompentC {
}
