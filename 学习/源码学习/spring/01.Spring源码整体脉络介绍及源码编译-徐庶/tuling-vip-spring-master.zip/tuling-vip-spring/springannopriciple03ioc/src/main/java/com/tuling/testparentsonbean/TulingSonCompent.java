package com.tuling.testparentsonbean;


/**
 * Created by smlz on 2019/6/3.
 */
public class TulingSonCompent extends TulingParentCompent {

    public void print(){
        getTulingCompent().siHi();
    }
}
