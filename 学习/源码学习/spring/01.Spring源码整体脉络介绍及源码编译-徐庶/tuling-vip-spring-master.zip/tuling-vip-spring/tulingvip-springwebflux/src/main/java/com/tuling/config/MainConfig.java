package com.tuling.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * Created by smlz on 2019/6/26.
 */
@Configuration
@ComponentScan(basePackages = {"com.tuling"})
public class MainConfig {


}
