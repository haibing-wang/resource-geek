package com.tuling.plugins.core.interceptors;

/**
 * Created by smlz on 2019/7/2.
 */
public class AngleTransactionInfo {
}
